def even(n):
    if n == 0:
        return True
    if (n % 10) % 2 != 0:
        return False
    return even(n // 10)

n = int(input("Enter Password: "))

if even(n):
    print("Strong Password")
else:
    print("Weak Password")

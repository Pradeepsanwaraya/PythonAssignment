def count(n, d):
    if n == 0:
        return 0
    if n % 10 == d:
        return 1 + count(n // 10, d)
    return count(n // 10, d)

n = int(input("Enter Ticket Number: "))
d = int(input("Enter Lucky Digit: "))

print("Digit", d, "appears", count(n, d), "times.")

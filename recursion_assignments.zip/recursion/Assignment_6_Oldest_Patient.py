from functools import reduce

patients = [
    ("Rahul", 45),
    ("Sneha", 62),
    ("Amit", 38),
    ("Kiran", 71),
    ("Pooja", 55)
]

x = reduce(lambda a, b: a if a[1] > b[1] else b, patients)

print("Oldest Patient:", x[0])

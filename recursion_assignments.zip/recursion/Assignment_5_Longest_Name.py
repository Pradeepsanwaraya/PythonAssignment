from functools import reduce

students = ["Riya", "Christopher", "Aman", "Neha", "Siddharth"]

x = reduce(lambda a, b: a if len(a) > len(b) else b, students)

print("Student with the longest name:", x)

def prime(n, d=2):
    if n < 2:
        return False
    if d * d > n:
        return True
    if n % d == 0:
        return False
    return prime(n, d + 1)

n = int(input("Enter Coupon Number: "))

if prime(n):
    print("Prime Number")
else:
    print("Not a Prime Number")

def comp(s, i=0):
    if i >= len(s):
        return ""

    c = s[i]
    j = i

    while j < len(s) and s[j] == c:
        j += 1

    return c + str(j - i) + comp(s, j)

s = input("Enter a String: ")

print("Compressed String =", comp(s))

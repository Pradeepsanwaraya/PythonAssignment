def rev(n, r=0):
    if n == 0:
        return r
    return rev(n // 10, r * 10 + n % 10)

n = int(input("Enter PIN: "))

if n == rev(n):
    print("Palindrome Number")
else:
    print("Not a Palindrome Number")

'''
12345
12345
12345
12345
12345

'''
n= int(input("Enter the number of lines .."))

i=1
while i<=n:
     j=1
     print()
     while j<n+1:
    
        print(j ,end=" ")
        j+=1
     i+=1
import winsound

winsound.MessageBeep()
print("System sound played")

def find(n, d):
    if n == 0:
        return False
    if n % 10 == d:
        return True
    return find(n // 10, d)

n = int(input("Enter Patient ID: "))
d = int(input("Enter Digit: "))

if find(n, d):
    print("Digit Found")
else:
    print("Digit Not Found")

from functools import reduce

players = [
    ("Virat", 78),
    ("Rohit", 102),
    ("Gill", 89),
    ("KL Rahul", 65),
    ("Iyer", 91)
]

x = reduce(lambda a, b: a if a[1] > b[1] else b, players)

print("Highest Run Scorer:", x[0])

def binary(n):
    if n == 0:
        return ""
    return binary(n // 2) + str(n % 2)

n = int(input("Enter a decimal number: "))

if n == 0:
    print("Binary Number = 0")
else:
    print("Binary Number =", binary(n))
